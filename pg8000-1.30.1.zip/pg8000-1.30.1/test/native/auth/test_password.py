def test_password(con):
    """Called by GitHub Actions with auth method password.
    We just need to check that we can get a connection.
    """
    pass
